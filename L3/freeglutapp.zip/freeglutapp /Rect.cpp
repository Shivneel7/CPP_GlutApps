#include "Rect.h"
#include <math.h>

#if defined WIN32
#include <freeglut.h>
#elif defined __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif

Rect::Rect(){
	x = 0;
	y = 0;
	red = 1;
	green = 0;
	blue = 0;

	w = 0.2;
	h = 0.2;

	xShape = false;
	circleShape = false;
}

Rect::Rect(float x, float y, float w, float h){
	this->x = x;
	this->y = y;

	red = 1;
	green = 0;
	blue = 0;

	this->w = w;
	this->h = h;

	xShape = false;
	circleShape = false;
}

Rect::Rect(float x, float y, float w, float h, float red, float green, float blue){
	this->x = x;
	this->y = y;

	this->red = red;
	this->green = green;
	this->blue = blue;

	this->w = w;
	this->h = h;

	xShape = false;
	circleShape = false;
}

bool Rect::contains(float x, float y){
	return (x > this->x) && (x < this->x + this->w) && (y < this->y) && (y > this->y - this->h);
}

void Rect::playX(){
	xShape = true;
}

void Rect::playCircle(){
	circleShape = true;
}



void Rect::draw(){

	if (circleShape){
		// Draw a circle in the box
		float cx = x + w/2;
		float cy = y - h/2;
		float r = (w - 0.2)/2;

		float theta = 0;
		float inc = M_PI/20;

		glBegin(GL_LINES);
		for (; theta < 2*M_PI; theta+=inc){
			glVertex2f(r*cos(theta) + cx, r*sin(theta) + cy);
			glVertex2f(r*cos(theta+inc) + cx, r*sin(theta+inc) + cy);
		}
		glEnd();
		
	}
	else if (xShape){
		// Draw an x in the box
		glColor3f(1,1,1);
		glBegin(GL_LINES);

		glVertex2f(x+0.1, y-0.1);
		glVertex2f(x+w-0.1, y-h+0.1);

		glVertex2f(x+w-0.1, y-0.1);
		glVertex2f(x+0.1, y-h+0.1);

		glEnd();
	}
	
	glColor3f(1,1,1);
	glBegin(GL_LINES);

	glVertex3f(x, y, 0.1);
	glVertex3f(x+w, y, 0.1);

	glVertex3f(x+w, y, 0.1);
	glVertex3f(x+w, y-h, 0.1);
	
	glVertex3f(x+w, y-h, 0.1);
	glVertex3f(x, y-h, 0.1);
	
	glVertex3f(x, y-h, 0.1);
	glVertex3f(x, y, 0.1);

	glEnd();
	
}
